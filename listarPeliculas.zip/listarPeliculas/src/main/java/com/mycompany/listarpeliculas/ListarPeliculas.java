/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.listarpeliculas;

/**
 *
 * @author Administrador
 */
public class ListarPeliculas {

    public static void main(String[] args) {
        
        Peliculas peli = new Peliculas();
        
        peli.setLocationRelativeTo(null);
        
        // Evita que se pueda modificar el tamaño del JFrame
        peli.setResizable(false);
        
        // Establece el tamaño del JFrame
        peli.setSize(415, 300);
        
        // Mostrar la ventana
        peli.setVisible(true);
    }
}
